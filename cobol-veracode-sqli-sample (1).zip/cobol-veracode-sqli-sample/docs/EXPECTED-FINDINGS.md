# Expected Findings

| File | Intent | Expected weakness |
|---|---|---|
| CUSTOMER-INQUIRY.cbl | Vulnerable | CWE-89 SQL Injection |
| ORDER-SEARCH.cbl | Vulnerable | CWE-89 SQL Injection |
| CUSTOMER-INQUIRY-FIXED.cbl | Safe comparison | No SQL injection expected |

The vulnerable samples model untrusted LINKAGE input flowing into dynamically constructed SQL and then into an SQL PREPARE sink. Exact Veracode finding names, line numbers, severity, and detection behavior depend on the scan engine and configuration.
