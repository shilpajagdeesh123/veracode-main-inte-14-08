# COBOL Veracode SQL Injection Test Project

Purpose: a deliberately vulnerable COBOL/DB2 sample for validating Veracode static-analysis and the Veracode-R remediation workflow in a non-production test repository.

## Test cases

- `src/CUSTOMER-INQUIRY.cbl` — intentionally concatenates `LK-CUSTOMER-ID` into dynamic SQL before `EXEC SQL PREPARE`. Expected category: SQL Injection / CWE-89.
- `src/ORDER-SEARCH.cbl` — intentionally concatenates search text into a dynamic `LIKE` SQL statement. Expected category: SQL Injection / CWE-89.
- `src/CUSTOMER-INQUIRY-FIXED.cbl` — safe comparison sample using a DB2 host variable rather than string-built SQL.

## Suggested Veracode test

1. Keep this project isolated from production code and data.
2. Scan the `src` directory with the existing Veracode-S workflow.
3. Confirm whether Veracode reports CWE-89 findings in the two intentionally vulnerable files.
4. Run Veracode-R against the generated `results.json`.
5. Review the generated knowledge graph and patch; do not apply automatically.
6. Compare remediation with `CUSTOMER-INQUIRY-FIXED.cbl`.

Do not deploy the vulnerable programs. They exist only as static-analysis fixtures.
