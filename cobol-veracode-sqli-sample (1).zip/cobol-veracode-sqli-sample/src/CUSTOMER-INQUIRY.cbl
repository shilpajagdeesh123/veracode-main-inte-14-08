       IDENTIFICATION DIVISION.
       PROGRAM-ID. CUSTOMER-INQUIRY.

       DATA DIVISION.
       WORKING-STORAGE SECTION.
       01  WS-CUSTOMER-ID        PIC X(20).
       01  WS-SQL                PIC X(500).
       01  WS-NAME               PIC X(60).
       01  WS-STATUS             PIC X(10).

       LINKAGE SECTION.
       01  LK-CUSTOMER-ID        PIC X(20).

       PROCEDURE DIVISION USING LK-CUSTOMER-ID.
           MOVE LK-CUSTOMER-ID TO WS-CUSTOMER-ID

      *    INTENTIONALLY VULNERABLE TEST CODE:
      *    Untrusted input is concatenated into dynamic SQL.
           STRING
               "SELECT NAME, STATUS FROM CUSTOMER WHERE CUSTOMER_ID = '"
               DELIMITED BY SIZE
               WS-CUSTOMER-ID DELIMITED BY SPACE
               "'" DELIMITED BY SIZE
               INTO WS-SQL
           END-STRING

           EXEC SQL
               PREPARE CUSTOMER-STMT FROM :WS-SQL
           END-EXEC

           EXEC SQL
               DECLARE CUSTOMER-CURSOR CURSOR FOR CUSTOMER-STMT
           END-EXEC

           EXEC SQL
               OPEN CUSTOMER-CURSOR
           END-EXEC

           EXEC SQL
               FETCH CUSTOMER-CURSOR
                 INTO :WS-NAME, :WS-STATUS
           END-EXEC

           EXEC SQL
               CLOSE CUSTOMER-CURSOR
           END-EXEC

           GOBACK.
