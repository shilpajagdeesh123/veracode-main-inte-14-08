@echo off
setlocal EnableExtensions
set "TOOL_HOME=%~dp0"
set "PYTHON_EXE=%TOOL_HOME%runtime\python\python.exe"
if not exist "%PYTHON_EXE%" (
  echo ERROR: Private Python runtime is missing. Run setup-runtime.bat first.
  exit /b 2
)
"%PYTHON_EXE%" "%TOOL_HOME%app\knowledge_graph\graph_builder.py" %*
exit /b %ERRORLEVEL%
