#!/usr/bin/env python3
"""Focused repository-local knowledge graph builder for Veracode remediation.

No external dependencies. It reads one authoritative results.json and only the
source files referenced by findings. It never performs vulnerability discovery.
"""
from __future__ import annotations
import argparse, json, re
from pathlib import Path
from datetime import datetime, timezone
from typing import Any

SEV = {5:'Critical',4:'High',3:'Medium',2:'Low',1:'Very Low',0:'Informational'}

def walk(obj: Any):
    if isinstance(obj, dict):
        yield obj
        for v in obj.values(): yield from walk(v)
    elif isinstance(obj, list):
        for v in obj: yield from walk(v)

def first(d, *keys):
    for k in keys:
        if k in d and d[k] not in (None, '', []): return d[k]
    return None

def findings(data):
    # Prefer common top-level arrays, then conservatively detect finding-like dicts.
    for k in ('findings','flaws','issues','results'):
        v = data.get(k) if isinstance(data, dict) else None
        if isinstance(v, list) and any(isinstance(x, dict) for x in v):
            return [x for x in v if isinstance(x, dict)]
    out=[]; seen=set()
    for d in walk(data):
        if not isinstance(d, dict): continue
        fid=first(d,'issue_id','finding_id','flaw_id','id')
        cwe=first(d,'cwe','cwe_id','cweid')
        path=first(d,'file','file_path','source_file','filename','sourcefile')
        if fid is not None and (cwe is not None or path is not None):
            key=(str(fid),str(path),str(cwe))
            if key not in seen: seen.add(key); out.append(d)
    return out

def norm_sev(v):
    if isinstance(v,(int,float)): return SEV.get(int(v),str(v))
    s=str(v or 'Unknown').strip(); low=s.lower()
    if low in ('5','very high','very_high','critical'): return 'Critical'
    if low in ('4','high'): return 'High'
    if low in ('3','medium'): return 'Medium'
    if low in ('2','low'): return 'Low'
    if low in ('1','very low','very_low'): return 'Very Low'
    if low in ('0','info','informational'): return 'Informational'
    return s

def clean_cwe(v):
    if isinstance(v, dict): v=first(v,'id','cwe_id','name')
    if v is None: return 'Unknown'
    s=str(v); m=re.search(r'(?:CWE[- ]?)?(\d+)',s,re.I)
    return 'CWE-'+m.group(1) if m else s

def resolve_path(repo: Path, raw):
    if not raw: return None
    p=Path(str(raw).replace('\\','/'))
    candidates=[repo/p]
    # Veracode paths sometimes carry packaging prefixes; suffix-match only referenced path.
    parts=p.parts
    for i in range(1,min(len(parts),6)):
        candidates.append(repo/Path(*parts[i:]))
    for c in candidates:
        try:
            if c.is_file(): return c.resolve()
        except OSError: pass
    return None

def analyze_source(path: Path):
    try: text=path.read_text(encoding='utf-8',errors='replace')
    except Exception: return {'language':'unknown','symbols':[],'calls':[]}
    ext=path.suffix.lower(); lang={'.java':'java','.kt':'kotlin','.ts':'typescript','.js':'javascript','.cbl':'cobol','.cob':'cobol','.py':'python'}.get(ext,ext.lstrip('.') or 'text')
    symbols=[]; calls=[]
    patterns=[]
    if lang=='java':
        patterns=[('class',r'\b(?:class|interface|enum|record)\s+([A-Za-z_$][\w$]*)'),('method',r'(?m)^\s*(?:public|protected|private|static|final|synchronized|abstract|native|default|\s)+[\w<>,.?\[\] ]+\s+([A-Za-z_$][\w$]*)\s*\([^;{}]*\)\s*(?:throws[^\{]+)?\{')]
    elif lang in ('typescript','javascript','kotlin','python'):
        patterns=[('function',r'(?m)^\s*(?:def|fun|function|async\s+function)\s+([A-Za-z_$][\w$]*)\s*\('),('class',r'\bclass\s+([A-Za-z_$][\w$]*)')]
    elif lang=='cobol':
        patterns=[('procedure',r'(?m)^\s{0,7}([A-Z0-9][A-Z0-9-]*)\.\s*$')]
    for typ,pat in patterns:
        for m in re.finditer(pat,text,re.I):
            line=text.count('\n',0,m.start())+1; symbols.append({'type':typ,'name':m.group(1),'line':line})
    # Calls are hints only; graph consumers must not treat them as proven data-flow.
    if lang in ('java','typescript','javascript','kotlin'):
        names=[]
        for m in re.finditer(r'\b([A-Za-z_$][\w$]*)\s*\(',text):
            n=m.group(1)
            if n not in {'if','for','while','switch','catch','return','new','throw','super','this'}: names.append(n)
        calls=sorted(set(names))[:1000]
    return {'language':lang,'symbols':symbols[:2000],'calls':calls}

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument('--repo-root',required=True); ap.add_argument('--results',required=True)
    ap.add_argument('--project',required=True); ap.add_argument('--scan-date',required=True); ap.add_argument('--output',required=True)
    args=ap.parse_args(); repo=Path(args.repo_root).resolve(); rp=Path(args.results).resolve(); out=Path(args.output).resolve(); out.mkdir(parents=True,exist_ok=True)
    data=json.loads(rp.read_text(encoding='utf-8-sig')); fs=findings(data)
    nodes={}; edges=[]; paths=[]
    def node(nid,typ,**attrs): nodes.setdefault(nid,{'id':nid,'type':typ,**attrs}); return nid
    project=node('project:'+args.project,'Project',name=args.project)
    file_cache={}
    for i,f in enumerate(fs,1):
        fid=str(first(f,'issue_id','finding_id','flaw_id','id') or i)
        cwe=clean_cwe(first(f,'cwe','cwe_id','cweid')); sev=norm_sev(first(f,'severity','severity_name','severity_text','severity_id'))
        raw=first(f,'file','file_path','source_file','filename','sourcefile'); line=first(f,'line','line_number','source_line','line_no')
        method=first(f,'method','method_name','function','procedure','function_name')
        source=first(f,'source','untrusted_source','source_name'); sink=first(f,'sink','risky_sink','sink_name')
        fn=node('finding:'+fid,'Finding',finding_id=fid,severity=sev,line=line,raw_file=raw,method=method)
        cn=node('cwe:'+cwe,'CWE',name=cwe); edges += [{'from':fn,'to':cn,'type':'HAS_CWE'},{'from':project,'to':fn,'type':'HAS_FINDING'}]
        resolved=resolve_path(repo,raw)
        rel=None
        if resolved:
            try: rel=resolved.relative_to(repo).as_posix()
            except ValueError: rel=str(resolved)
            file_id=node('file:'+rel,'File',path=rel)
            edges.append({'from':fn,'to':file_id,'type':'AFFECTS'})
            if rel not in file_cache: file_cache[rel]=analyze_source(resolved)
            a=file_cache[rel]
            for s in a['symbols']:
                sid=node('symbol:'+rel+':'+s['type']+':'+s['name']+':'+str(s['line']),'Symbol',name=s['name'],symbol_type=s['type'],line=s['line'],file=rel)
                edges.append({'from':file_id,'to':sid,'type':'DEFINES'})
                if method and str(method)==s['name']: edges.append({'from':fn,'to':sid,'type':'AFFECTS_SYMBOL'})
        srcid=None; sinkid=None
        if source:
            srcid=node('source:'+str(source),'Source',name=str(source)); edges.append({'from':fn,'to':srcid,'type':'REPORTS_SOURCE'})
        if sink:
            sinkid=node('sink:'+str(sink),'Sink',name=str(sink)); edges.append({'from':fn,'to':sinkid,'type':'REPORTS_SINK'})
        p={'finding_id':fid,'cwe':cwe,'severity':sev,'file':rel or raw,'line':line,'method':method,'source':source,'sink':sink,'path_confidence':'reported-by-veracode' if (source or sink) else 'context-only'}
        paths.append(p)
    graph={'schema_version':'1.0','generated_at':datetime.now(timezone.utc).isoformat(),'scope':'focused-remediation-context-only','project':args.project,'scan_date':args.scan_date,'authoritative_results':str(rp),'nodes':sorted(nodes.values(),key=lambda x:x['id']),'edges':edges,'source_analysis':file_cache,'limitations':['No vulnerability discovery is performed.','Only files referenced by results.json are opened.','Source/sink relationships come from Veracode fields when present.','Static call-name extraction is contextual and is not proof of data flow.']}
    (out/'graph.json').write_text(json.dumps(graph,indent=2),encoding='utf-8')
    (out/'vulnerability-paths.json').write_text(json.dumps({'project':args.project,'scan_date':args.scan_date,'paths':paths},indent=2),encoding='utf-8')
    print('Knowledge graph generated:',out/'graph.json'); print('Findings:',len(fs),'Referenced source files analyzed:',len(file_cache))
if __name__=='__main__': main()
