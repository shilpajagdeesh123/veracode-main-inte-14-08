# Focused remediation knowledge graph

`graph_builder.py` builds a local JSON graph from the selected Veracode `results.json` and only the source files referenced by those findings. It does not scan for new vulnerabilities and requires no external graph database or Python dependency.

Outputs belong under repository root `.github/output/knowledge-graph/<project>/<scan-date>/` and never under `.fus/output`.
