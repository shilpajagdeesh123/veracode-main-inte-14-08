# Veracode Enterprise V6.8

## Repository layout

```text
repository-root/
├── .github/
│   ├── agents/
│   ├── skills/
│   ├── output/veracode/                 # generated scan results
│   └── remediation/veracode/            # generated remediation patches
└── veracode-enterprise/
    ├── app/
    ├── config/
    ├── runtime/
    ├── runtime-veracode.bat              # Windows
    ├── runtime-veracode.sh               # macOS
    ├── run-Veracode.bat
    ├── run-Veracode.sh
    ├── setup-runtime.bat
    └── setup-runtime.sh
```

## Start from GitHub Copilot

Select `veracode-agent` and enter:

```text
Start Veracode API scan
```

The agent detects Windows/macOS, submits the matching launcher in the IntelliJ integrated terminal, and stops immediately. Starting the agent again creates a fresh transient scan session and starts from Step 1. Valid credentials and historical reports are preserved.

## Direct execution

Windows:

```bat
veracode-enterprise\runtime-veracode.bat
```

macOS:

```bash
bash veracode-enterprise/runtime-veracode.sh
```

## Output

Scan results:

```text
.github/output/veracode/<project-or-module>/<YYYY-MM-DD>/
```

Same-day repeat runs may add a `<HHMMSS>` subfolder.

Remediation:

```text
.github/output/remediation/veracode/<project-or-module>/<selected-scan-date>/
```

The scan client retrieves and consolidates all findings pages into `results.json` after the scan succeeds. Polling begins immediately and uses bounded backoff to reduce unnecessary waiting and API calls.


## Knowledge-graph-assisted remediation

`Veracode-R` now uses a focused local JSON knowledge graph between `results.json` and patch generation. The graph is generated under `.github/output/knowledge-graph/<project>/<scan-date>/` from confirmed findings and affected source context only. No Neo4j or external graph database is required. Patch generation remains one consolidated Git unified diff per affected source file, and `Veracode-P` remains the separate approval-controlled apply stage.
