# Veracode remediation skill

Copilot project skill location:

`.GitHub/skills/veracode-remediation/SKILL.md`

The skill is intentionally driven by the raw Pipeline Scan `results.json`.
The custom remediation agent references this skill and should use it automatically
when performing Veracode remediation work.
