---
name: veracode-agent
description: Cross-platform terminal handoff for a fresh Veracode scan session.
---

# Veracode Scan Terminal-Handoff Skill

## Trigger

`Start Veracode API scan`

## Required behavior

- Determine whether the IDE is running on Windows or macOS.
- Use a new/fresh IntelliJ integrated terminal rooted at the repository root.
- Windows command: `cmd.exe /d /c "veracode-enterprise\runtime-veracode.bat"`
- macOS command: `bash "veracode-enterprise/runtime-veracode.sh"`
- Submit exactly one launcher command.
- End the Copilot agent turn immediately after command submission.
- Never wait for scan completion, read terminal output, answer terminal prompts, or perform remediation.
- Never expose HMAC credentials in chat.

## Fresh-start contract

Every trigger submits the launcher again. The launcher clears only transient `veracode-enterprise/runtime/session` state and starts runtime, credential, selection, packaging, upload, polling, and result generation from Step 1. It preserves valid credentials and historical output.

## Unsupported OS

For operating systems other than Windows or macOS, stop and state that this package supports Windows and macOS only.
