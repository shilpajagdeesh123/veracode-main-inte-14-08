#!/usr/bin/env bash
set -euo pipefail
TOOL_HOME="$(cd "$(dirname "$0")" && pwd)"
cd "$TOOL_HOME"

# Fresh execution state on every start. Credentials and historical reports are preserved.
rm -rf "$TOOL_HOME/runtime/session"
mkdir -p "$TOOL_HOME/runtime/session"
export VERACODE_SESSION_ID="$(date +%Y%m%d-%H%M%S)-$$"

clear 2>/dev/null || true
echo "=========================================================="
echo " Veracode Enterprise - Fresh Scan Session (macOS)"
echo "=========================================================="
echo "Starting the workflow from Step 1..."
echo
exec "$TOOL_HOME/run-Veracode.sh"
