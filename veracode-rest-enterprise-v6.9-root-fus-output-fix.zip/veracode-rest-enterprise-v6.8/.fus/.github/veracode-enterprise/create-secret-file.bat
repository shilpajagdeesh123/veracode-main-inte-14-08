@echo off
setlocal EnableExtensions
for %%I in ("%~dp0.") do set "TOOL_HOME=%%~fI"
set "PYTHON_EXE=%TOOL_HOME%\runtime\python\python.exe"

if not exist "%PYTHON_EXE%" (
    call "%TOOL_HOME%\setup-runtime.bat"
    if errorlevel 1 exit /b 2
)

"%PYTHON_EXE%" "%TOOL_HOME%\app\configure_credentials.py" "%TOOL_HOME%"
exit /b %ERRORLEVEL%
