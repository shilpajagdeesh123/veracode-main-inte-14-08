# Veracode UI and Pipeline Scan result comparison

The Pipeline Scan REST API scans the package created during the current local run. The Veracode Platform application page can show findings from a different uploaded artifact, a policy scan, a sandbox, an older build, or findings accumulated in the application profile.

For an exact comparison:

1. Open `.github/output/veracode/<project>/<date>/package/package-manifest.json`.
2. Confirm the file count and source paths match the artifact uploaded through the Veracode UI.
3. Compare the current Pipeline Scan only with the same build artifact and scan type.
4. Review `results.json` for the complete raw REST response.
5. Review `veracode-findings.json` or `results.csv` for normalized severity totals.

The Pipeline Scan API can report up to 200 flaws. If more than 200 flaws exist, the result is not equivalent to a complete historical application-profile finding list. For application-profile results, use the Veracode Findings API with the application GUID and its pagination rather than the Pipeline Scan endpoint.
