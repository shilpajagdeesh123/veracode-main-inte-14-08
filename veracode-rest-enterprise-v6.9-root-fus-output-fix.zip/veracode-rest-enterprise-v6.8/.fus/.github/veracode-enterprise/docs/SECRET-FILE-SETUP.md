# HMAC secret-file setup

V5 reads Veracode HMAC credentials from:

```text
config\veracode-secrets.json
```

## Create it

Run:

```bat
create-secret-file.bat
```

Then edit:

```json
{
  "api_id": "YOUR_HMAC_API_ID",
  "api_key": "YOUR_HMAC_API_KEY",
  "api_host": "api.veracode.com"
}
```

Run:

```bat
run-veracode.bat
```

`config/veracode-secrets.json` is included in `.gitignore`.

Do not commit, paste into Copilot, or copy into `.github/output`.
