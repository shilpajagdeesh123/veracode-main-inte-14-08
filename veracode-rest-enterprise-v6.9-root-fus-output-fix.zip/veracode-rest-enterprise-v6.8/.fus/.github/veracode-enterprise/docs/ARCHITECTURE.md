# Architecture

```text
Developer changes code
        |
        v
run-veracode.bat
        |
        v
local embedded python.exe
        |
        +--> choose PROJECT / MODULE
        |
        +--> Java build or Angular/Node source package
        |
        +--> SHA-256 + artifact size
        |
        +--> Veracode HMAC REST
                |
                +--> POST /pipeline_scan/v1/scans
                +--> split according to binary_segments_expected
                +--> PUT /segments/{n}
                +--> PUT scan_status=STARTED
                +--> GET scan status
                +--> GET /findings
        |
        v
.github/output/veracode/<target>/<date>/
        |
        +--> results.json
        +--> veracode-findings.json
        +--> scan-status.json
        +--> scan-metadata.json
        |
        v
Copilot remediation agent
        |
        v
rebuild + re-scan
        |
        v
PASS -> commit
```
