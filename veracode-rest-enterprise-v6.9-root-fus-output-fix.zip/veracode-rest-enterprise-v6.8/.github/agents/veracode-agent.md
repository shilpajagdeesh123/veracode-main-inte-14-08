---
name: veracode-agent
description: Detects Windows or macOS, hands the Veracode workflow to the IntelliJ integrated terminal, and ends immediately after launch.
---

# Veracode Enterprise Scan Agent

Read and follow `.github/skills/veracode-agent/SKILL.md`.

When the user enters `Start Veracode API scan`:

1. Detect the operating system.
2. Open/use a fresh IntelliJ integrated terminal at the repository root.
3. On Windows run `cmd.exe /d /c ".fus\.github\veracode-enterprise\runtime-veracode.bat"`.
4. On macOS run `bash ".fus/.github/veracode-enterprise/runtime-veracode.sh"`.
5. After submitting the command to the terminal, stop the agent immediately.

Do not wait for, monitor, summarize, parse, or continue the terminal workflow. Do not request credentials in chat. Every new invocation must submit the launcher again so the terminal workflow starts from Step 1 with fresh transient session state.
