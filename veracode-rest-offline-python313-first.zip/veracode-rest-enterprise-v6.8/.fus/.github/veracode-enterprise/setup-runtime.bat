@echo off
setlocal EnableExtensions EnableDelayedExpansion

set "TOOL_HOME=%~dp0"
set "RUNTIME_ROOT=%TOOL_HOME%runtime"
set "RUNTIME_DIR=%RUNTIME_ROOT%\python"
set "PACKAGE_DIR=%RUNTIME_ROOT%\package"
set "LOCAL_ZIP=%PACKAGE_DIR%\python-3.13.14-embed-amd64.zip"
set "TMP_DIR=%RUNTIME_ROOT%\download"
set "DOWNLOADED_ZIP=%TMP_DIR%\python-3.13.14-embed-amd64.zip"

set "PY_URL=https://www.python.org/ftp/python/3.13.14/python-3.13.14-embed-amd64.zip"
set "PY_SHA256=90b4e5b9898b72d744650524bff92377c367f44bd5fbd09e3148656c080ad907"

echo ==========================================================
echo  Veracode Private Python 3.13 Runtime Setup
echo ==========================================================
echo.
echo System/Anaconda/PATH Python installations are ignored.
echo.

REM ----------------------------------------------------------
REM 1. Reuse already-installed private Python 3.13
REM ----------------------------------------------------------
if exist "%RUNTIME_DIR%\python.exe" (
    "%RUNTIME_DIR%\python.exe" -c "import sys; sys.exit(0 if sys.version_info[:2] == (3,13) else 1)" >nul 2>&1
    if not errorlevel 1 (
        echo Private Python 3.13 already available:
        "%RUNTIME_DIR%\python.exe" --version
        exit /b 0
    )

    echo Existing private runtime is not Python 3.13.
    echo Removing invalid private runtime...
    rmdir /s /q "%RUNTIME_DIR%" >nul 2>&1
)

if not exist "%PACKAGE_DIR%" mkdir "%PACKAGE_DIR%"
if not exist "%RUNTIME_DIR%" mkdir "%RUNTIME_DIR%"

REM ----------------------------------------------------------
REM 2. OFFLINE-FIRST: use Python ZIP bundled with package
REM ----------------------------------------------------------
if exist "%LOCAL_ZIP%" (
    echo Found bundled offline Python package:
    echo   %LOCAL_ZIP%
    set "SOURCE_ZIP=%LOCAL_ZIP%"
    goto :verify_and_extract
)

REM ----------------------------------------------------------
REM 3. No bundled ZIP: online download is last fallback only
REM ----------------------------------------------------------
echo.
echo Bundled Python ZIP was not found.
echo Expected:
echo   %LOCAL_ZIP%
echo.
echo Attempting online download only as fallback...

where curl.exe >nul 2>&1
if errorlevel 1 (
    echo.
    echo ERROR: curl.exe is unavailable and no bundled Python ZIP exists.
    echo Place the official Python 3.13.14 Windows embeddable ZIP here:
    echo   %LOCAL_ZIP%
    exit /b 2
)

if not exist "%TMP_DIR%" mkdir "%TMP_DIR%"

curl.exe --fail --location --output "%DOWNLOADED_ZIP%" "%PY_URL%"
if errorlevel 1 (
    echo.
    echo ERROR: Online Python download failed.
    echo This commonly occurs on corporate proxy/TLS networks.
    echo.
    echo OFFLINE FIX:
    echo Copy the official file:
    echo   python-3.13.14-embed-amd64.zip
    echo to:
    echo   %LOCAL_ZIP%
    echo.
    echo Then rerun run-Veracode.bat.
    exit /b 3
)

set "SOURCE_ZIP=%DOWNLOADED_ZIP%"

:verify_and_extract

REM ----------------------------------------------------------
REM 4. Verify official SHA-256
REM ----------------------------------------------------------
where certutil.exe >nul 2>&1
if errorlevel 1 (
    echo ERROR: certutil.exe is required for SHA-256 verification.
    exit /b 4
)

echo Verifying Python 3.13.14 SHA-256...
set "ACTUAL_HASH="
for /f "skip=1 tokens=* delims=" %%H in ('certutil.exe -hashfile "%SOURCE_ZIP%" SHA256 ^| findstr /R /V /C:"hash of file" /C:"CertUtil"') do (
    set "ACTUAL_HASH=%%H"
    goto :hashdone
)
:hashdone
set "ACTUAL_HASH=%ACTUAL_HASH: =%"

if /I not "%ACTUAL_HASH%"=="%PY_SHA256%" (
    echo ERROR: Python runtime SHA-256 mismatch.
    echo Expected: %PY_SHA256%
    echo Actual:   %ACTUAL_HASH%
    exit /b 5
)

REM ----------------------------------------------------------
REM 5. Extract locally
REM ----------------------------------------------------------
where tar.exe >nul 2>&1
if errorlevel 1 (
    echo ERROR: tar.exe is required to extract the embeddable ZIP.
    exit /b 6
)

echo Extracting private Python 3.13 runtime...
tar.exe -xf "%SOURCE_ZIP%" -C "%RUNTIME_DIR%"
if errorlevel 1 (
    echo ERROR: Python extraction failed.
    exit /b 7
)

if not exist "%RUNTIME_DIR%\python.exe" (
    echo ERROR: python.exe was not found after extraction.
    exit /b 7
)

"%RUNTIME_DIR%\python.exe" -c "import sys; sys.exit(0 if sys.version_info[:2] == (3,13) else 1)" >nul 2>&1
if errorlevel 1 (
    echo ERROR: Extracted runtime is not Python 3.13.
    exit /b 8
)

echo.
echo Private Python 3.13 runtime initialized successfully:
"%RUNTIME_DIR%\python.exe" --version
exit /b 0
