OFFLINE PYTHON PACKAGE LOCATION

This Veracode package always uses its own private Python 3.13 runtime.
It ignores all Python versions installed on the workstation.

For corporate machines where curl/Python.org download is blocked, place:

  python-3.13.14-embed-amd64.zip

in this directory:

  .fus/.github/veracode-enterprise/runtime/package/

Expected full path:

  ROOT/.fus/.github/veracode-enterprise/runtime/package/python-3.13.14-embed-amd64.zip

The setup script verifies this official SHA-256 before extracting:

  90b4e5b9898b72d744650524bff92377c367f44bd5fbd09e3148656c080ad907

Execution order:

1. Existing private runtime/python/python.exe (must be Python 3.13)
2. Bundled runtime/package/python-3.13.14-embed-amd64.zip
3. Internet download from python.org as LAST fallback only

After extraction, future runs use:

  ROOT/.fus/.github/veracode-enterprise/runtime/python/python.exe

No system/Anaconda/PATH Python is ever used.

Generated Veracode output remains:

  ROOT/.github/output

Never:

  ROOT/.fus/output
