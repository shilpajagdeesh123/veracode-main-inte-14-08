@echo off
REM Runtime selection policy:
REM   1. Use already bundled portable Python 3.13 if present.
REM   2. Otherwise use local/system Python ONLY when it is exactly Python 3.6.x.
REM   3. Otherwise return failure so caller downloads the bundled Python 3.13 runtime.
REM
REM Returned variables:
REM   PYTHON_EXE
REM   PYTHON_ARGS

set "PYTHON_EXE="
set "PYTHON_ARGS="
set "BUNDLED_PYTHON=%TOOL_HOME%\runtime\python\python.exe"

REM 1. Prefer already-bundled Python 3.13.
if exist "%BUNDLED_PYTHON%" (
    "%BUNDLED_PYTHON%" -c "import sys; sys.exit(0 if sys.version_info[:2] == (3,13) else 1)" >nul 2>&1
    if not errorlevel 1 (
        set "PYTHON_EXE=%BUNDLED_PYTHON%"
        goto :python_selected
    )
)

REM 2. Detect system/Anaconda Python 3.6.x specifically.
where python.exe >nul 2>&1
if not errorlevel 1 (
    python.exe -c "import sys; sys.exit(0 if sys.version_info[:2] == (3,6) else 1)" >nul 2>&1
    if not errorlevel 1 (
        set "PYTHON_EXE=python.exe"
        goto :python_selected
    )
)

REM 3. Try Windows Python Launcher specifically for Python 3.6.
where py.exe >nul 2>&1
if not errorlevel 1 (
    py.exe -3.6 -c "import sys; sys.exit(0 if sys.version_info[:2] == (3,6) else 1)" >nul 2>&1
    if not errorlevel 1 (
        set "PYTHON_EXE=py.exe"
        set "PYTHON_ARGS=-3.6"
        goto :python_selected
    )
)

REM No Python 3.6 and no bundled Python 3.13.
exit /b 1

:python_selected
exit /b 0
