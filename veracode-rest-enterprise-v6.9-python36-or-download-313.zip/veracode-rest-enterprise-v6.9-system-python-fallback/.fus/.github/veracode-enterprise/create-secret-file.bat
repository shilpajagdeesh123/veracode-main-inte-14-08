@echo off
setlocal EnableExtensions
for %%I in ("%~dp0.") do set "TOOL_HOME=%%~fI"

call "%TOOL_HOME%\select-python.bat"
if errorlevel 1 (
    echo Python 3.6 was not detected and bundled Python 3.13 is not available.
    echo Downloading/setup of bundled Python 3.13 will now start...
    call "%TOOL_HOME%\setup-runtime.bat"
    if errorlevel 1 exit /b 2
    call "%TOOL_HOME%\select-python.bat"
    if errorlevel 1 exit /b 2
)

echo Using Python:
"%PYTHON_EXE%" %PYTHON_ARGS% --version

"%PYTHON_EXE%" %PYTHON_ARGS% "%TOOL_HOME%\app\configure_credentials.py" "%TOOL_HOME%"
exit /b %ERRORLEVEL%
