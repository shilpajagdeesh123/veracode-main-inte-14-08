@echo off
setlocal EnableExtensions

for %%I in ("%~dp0.") do set "TOOL_HOME=%%~fI"

echo ==========================================================
echo  Veracode Enterprise Scan Launcher
echo ==========================================================
echo.

echo Step 1: Selecting Python runtime...
call "%TOOL_HOME%\select-python.bat"

if errorlevel 1 (
    echo Python 3.6 was not detected and bundled Python 3.13 is not available.
    echo Downloading/setup of bundled Python 3.13 will now start...
    call "%TOOL_HOME%\setup-runtime.bat"
    if errorlevel 1 (
        echo.
        echo ERROR: Python runtime setup failed.
        echo.
        echo If this machine is behind a corporate proxy/TLS gateway,
        echo the portable Python download may be blocked.
        echo Install/configure Python 3.6 on PATH, or ask desktop
        echo engineering to pre-stage the verified portable runtime.
        exit /b 2
    )
    call "%TOOL_HOME%\select-python.bat"
    if errorlevel 1 (
        echo ERROR: Python runtime is still unavailable after setup.
        exit /b 2
    )
)

echo Python runtime selected:
"%PYTHON_EXE%" %PYTHON_ARGS% --version
if errorlevel 1 (
    echo ERROR: Selected Python runtime could not start.
    exit /b 2
)

"%PYTHON_EXE%" %PYTHON_ARGS% -c "import sys; print('Python executable:', sys.executable)"
if errorlevel 1 exit /b 2

echo.
echo Step 2: Checking Veracode HMAC credentials...
"%PYTHON_EXE%" %PYTHON_ARGS% "%TOOL_HOME%\app\configure_credentials.py" "%TOOL_HOME%"
if errorlevel 1 (
    echo.
    echo ERROR: Veracode credential setup failed.
    exit /b 3
)

if not exist "%TOOL_HOME%\config\scanner.json" (
    echo ERROR: scanner.json was not found:
    echo   %TOOL_HOME%\config\scanner.json
    exit /b 4
)

echo.
echo Step 3: Starting Veracode scan workflow...
echo Tool home: %TOOL_HOME%
echo Scan/remediation output root is the repository .github\output directory.
echo.
"%PYTHON_EXE%" %PYTHON_ARGS% "%TOOL_HOME%\app\veracode_precommit.py" --tool-home "%TOOL_HOME%"
set "EXIT_CODE=%ERRORLEVEL%"

echo.
if "%EXIT_CODE%"=="0" (
    echo Veracode workflow completed successfully.
) else (
    echo Veracode workflow ended with exit code %EXIT_CODE%.
)
exit /b %EXIT_CODE%
