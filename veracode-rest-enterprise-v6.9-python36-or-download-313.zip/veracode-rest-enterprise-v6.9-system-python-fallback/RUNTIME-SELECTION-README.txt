v6.9 runtime selection update

Windows runtime policy:

1. If bundled Python 3.13 is already available:
   use bundled Python 3.13.

2. Otherwise check the machine for Python 3.6.x:
   - python.exe on PATH (including Anaconda)
   - py.exe -3.6

3. If Python 3.6.x is NOT detected:
   run setup-runtime.bat and download/setup Python 3.13.

Tool location:
  ROOT/.fus/.github/veracode-enterprise

Generated outputs:
  ROOT/.github/output

Never:
  ROOT/.fus/output
