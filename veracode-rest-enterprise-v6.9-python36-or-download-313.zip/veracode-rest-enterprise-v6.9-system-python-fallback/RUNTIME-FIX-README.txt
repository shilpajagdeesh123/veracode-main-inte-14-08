v6.9 runtime fallback fix

Windows runtime order:
1. Existing bundled portable Python
2. Existing python.exe on PATH (including Anaconda)
3. Windows py -3 launcher
4. setup-runtime.bat download only as last fallback

Minimum accepted runtime: Python 3.6.

This prevents an unnecessary Python 3.13 download when a usable local
Python installation already exists.

The Veracode tool remains under:
  ROOT/.fus/.github/veracode-enterprise

Generated scan/remediation artifacts remain under:
  ROOT/.github/output

No generated output should be written to ROOT/.fus/output.
