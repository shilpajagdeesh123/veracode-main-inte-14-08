@echo off
setlocal EnableExtensions

for %%I in ("%~dp0.") do set "TOOL_HOME=%%~fI"
set "PYTHON_EXE=%TOOL_HOME%\runtime\python\python.exe"

echo ==========================================================
echo  Veracode Enterprise Scan Launcher
echo ==========================================================
echo.

echo Step 1: Checking private Python 3.13 runtime...
echo NOTE: System/Anaconda/PATH Python installations are intentionally ignored.

set "PRIVATE_PYTHON_OK=0"
if exist "%PYTHON_EXE%" (
    "%PYTHON_EXE%" -c "import sys; sys.exit(0 if sys.version_info[:2] == (3,13) else 1)" >nul 2>&1
    if not errorlevel 1 set "PRIVATE_PYTHON_OK=1"
)

if "%PRIVATE_PYTHON_OK%"=="0" (
    echo Private Python 3.13 runtime was not found or is not Python 3.13.
    echo Running setup-runtime.bat...
    call "%TOOL_HOME%\setup-runtime.bat"
    if errorlevel 1 (
        echo.
        echo ERROR: Python 3.13 runtime setup failed.
        exit /b 2
    )
)

if not exist "%PYTHON_EXE%" (
    echo ERROR: Private Python runtime is still unavailable after setup.
    exit /b 2
)

"%PYTHON_EXE%" -c "import sys; sys.exit(0 if sys.version_info[:2] == (3,13) else 1)" >nul 2>&1
if errorlevel 1 (
    echo ERROR: Private runtime exists but is not Python 3.13.
    exit /b 2
)

echo Python runtime selected:
"%PYTHON_EXE%" --version
"%PYTHON_EXE%" -c "import sys; print('Python executable:', sys.executable)"

echo.
echo Step 2: Checking Veracode HMAC credentials...
"%PYTHON_EXE%" "%TOOL_HOME%\app\configure_credentials.py" "%TOOL_HOME%"
if errorlevel 1 (
    echo.
    echo ERROR: Veracode credential setup failed.
    exit /b 3
)

if not exist "%TOOL_HOME%\config\scanner.json" (
    echo ERROR: scanner.json was not found:
    echo   %TOOL_HOME%\config\scanner.json
    exit /b 4
)

echo.
echo Step 3: Starting Veracode scan workflow...
echo Tool home: %TOOL_HOME%
echo.
"%PYTHON_EXE%" "%TOOL_HOME%\app\veracode_precommit.py" --tool-home "%TOOL_HOME%"
set "EXIT_CODE=%ERRORLEVEL%"

echo.
if "%EXIT_CODE%"=="0" (
    echo Veracode workflow completed successfully.
) else (
    echo Veracode workflow ended with exit code %EXIT_CODE%.
)
exit /b %EXIT_CODE%
