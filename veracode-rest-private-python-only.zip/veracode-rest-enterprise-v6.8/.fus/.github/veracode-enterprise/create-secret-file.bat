@echo off
setlocal EnableExtensions
for %%I in ("%~dp0.") do set "TOOL_HOME=%%~fI"
set "PYTHON_EXE=%TOOL_HOME%\runtime\python\python.exe"

echo Checking private Python 3.13 runtime...
echo NOTE: System/Anaconda/PATH Python installations are intentionally ignored.

set "PRIVATE_PYTHON_OK=0"
if exist "%PYTHON_EXE%" (
    "%PYTHON_EXE%" -c "import sys; sys.exit(0 if sys.version_info[:2] == (3,13) else 1)" >nul 2>&1
    if not errorlevel 1 set "PRIVATE_PYTHON_OK=1"
)

if "%PRIVATE_PYTHON_OK%"=="0" (
    call "%TOOL_HOME%\setup-runtime.bat"
    if errorlevel 1 exit /b 2
)

"%PYTHON_EXE%" "%TOOL_HOME%\app\configure_credentials.py" "%TOOL_HOME%"
exit /b %ERRORLEVEL%
